﻿using System;
using System.Collections.Generic;

namespace ConsoleProjektH1
{
	class Program
	{
		static void Main(string[] args)
		{
			MyFunctions mf = new MyFunctions();
			List<string> nameList = new List<string>
			{
				"Ole",
				"Peter",
				"Jonna",
				"Finn",
				"Heidi"
			};

			while (true)
			{
				Console.Write(":>");
				string input = Console.ReadLine();

				if (input == "showall")
				{
					mf.ShowAll(nameList);
				}
				else if (input.ToLower().StartsWith("addperson"))
				{
					string newString = input.Substring(input.IndexOf(input+1));
					mf.AddPerson(nameList, input);
				}
				else if (input.ToLower().StartsWith("deleteperson"))
				{
					string newString = input.Substring(input.IndexOf(input+1));
					mf.DeletePerson(nameList, input);
				}
				else if (input.ToLower().StartsWith("changeperson"))
				{
					string[] stringArray = input.Split(' ');
					mf.ChangePerson(nameList, stringArray[1], stringArray[2]);
				}
			}

		}
	}

	class MyFunctions
	{
		// Show the entire list
		public void ShowAll(List<string> myList)
		{
			for (int i = 0; i < myList.Count; i++)
			{
				Console.WriteLine(myList[i]);
			}
		}

		// Add a person at the end of the list
		public void AddPerson(List<string> myList, string b)
		{
			myList.Add(b);
		}

		// Add a person at a specific position
		public void AddPerson(List<string> myList, string b, int c)
		{
			myList.Insert(c, b);
		}

		// Remove a person with a specific name
		public void DeletePerson(List<string> myList, string b)
		{
			myList.Remove(b);
		}

		// Remove a person from a specific position
		public void DeletePerson(List<string> myList, int b)
		{
			myList.RemoveAt(b);
		}
		
		// Change the person with a specific name, to another name
		public void ChangePerson(List<string> myList, string b, string c)
		{
			myList[myList.IndexOf(b)] = c;
		}

		// Change the person on a specific position
		public void ChangePerson(List<string> myList, int b, string c)
		{
			myList[b] = c;
		}


	}
}
