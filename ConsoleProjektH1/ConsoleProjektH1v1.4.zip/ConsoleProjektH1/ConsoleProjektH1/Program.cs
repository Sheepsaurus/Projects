﻿using System;
using System.Collections.Generic;

namespace ConsoleProjektH1
{
	class Program
	{
		static void Main(string[] args)
		{
			MyFunctions mf = new MyFunctions();
			List<string> nameList = new List<string>
			{
				"Ole",
				"Peter",
				"Jonna",
				"Finn",
				"Heidi"
			};

			while (true)
			{
				Console.Write(":>");
				string input = Console.ReadLine().ToLower();

				switch (input)
				{
					case "showall":
						mf.ShowAll(nameList);
						break;
					default:
						if (input.StartsWith("addperson"))
						{
							mf.AddPerson(nameList, input.Substring("addperson".Length + 1).Replace(" ", ""));
						}
						else if (input.StartsWith("deleteperson"))
						{
							mf.DeletePerson(nameList, input.Substring("deleteperson".Length + 1).Replace(" ", ""));
						}
						else if (input.StartsWith("changeperson"))
						{
							string[] stringArray = input.Split(' ');
							mf.ChangePerson(nameList, stringArray[1], stringArray[2]);
						}
						break;
				}				
			}
		}
	}

	class MyFunctions
	{
		// Show the entire list
		public void ShowAll(List<string> myList)
		{
			for (int i = 0; i < myList.Count; i++)
			{
				Console.WriteLine(myList[i]);
			}
		}

		// Add a person at the end of the list
		public void AddPerson(List<string> myList, string b)
		{
			myList.Add(Capitalize(b));
		}

		// Add a person at a specific position
		public void AddPerson(List<string> myList, string b, int c)
		{
			myList.Insert(c, Capitalize(b));
		}

		// Remove a person with a specific name
		public void DeletePerson(List<string> myList, string b)
		{
			myList.Remove(Capitalize(b));
		}

		// Remove a person from a specific position
		public void DeletePerson(List<string> myList, int b)
		{
            myList.RemoveAt(b);
		}
		
		// Change the person with a specific name, to another name
		public void ChangePerson(List<string> myList, string b, string c)
		{
			myList[myList.IndexOf(Capitalize(b))] = Capitalize(c);
		}

		// Change the person on a specific position
		public void ChangePerson(List<string> myList, int b, string c)
		{
			myList[b] = Capitalize(c);
		}

		public string Capitalize(string a)
		{
			char[] newCharArray = a.ToCharArray();
			newCharArray[0] = char.ToUpper(a[0]);			
			return new string(newCharArray);
		}
	}
}
